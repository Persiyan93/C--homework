﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Food.Contracts
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
