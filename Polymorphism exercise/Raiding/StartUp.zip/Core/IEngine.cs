﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Core
{
    interface IEngine
    {
         void Run();
    }
}
