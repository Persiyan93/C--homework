﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Football.Common
{
    public static class  CommonConst
    {
        public static  string InvalidMessage=("{0} should be between 0 and 100.");
    }
}
