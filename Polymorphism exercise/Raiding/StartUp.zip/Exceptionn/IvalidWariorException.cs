﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Exceptionn
{
    public class IvalidWariorException : Exception
    {
        public IvalidWariorException(string message) : base(message)
        {
            
        }
    }
}
