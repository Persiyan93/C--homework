﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raw
{
   public  class Engine
    {
        public int EngineSpeed { get; set; }
        public int Power { get; set; }
    }
}
