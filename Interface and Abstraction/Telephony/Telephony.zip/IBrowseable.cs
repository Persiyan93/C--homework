﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface IBrowseable
    {
        public string Browse(string website);
    }
}
