﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raw
{
   public class Cargo
    {
        public int Cargoweight { get; set; }
        public string Cargotype { get; set; }

    }
}
